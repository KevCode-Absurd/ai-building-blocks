Actual cost-forecast output from the specialist run, plus its two synthetic source files.
Open output/forecast.html in a browser. CSV and JSON files are editable working data.
All original file bytes and relative source links are preserved. No real merchant data is included.
The forecast is a static scenario report, not an interactive calculator or a live supplier quote.
Source records are synthetic test fixtures. Their instructions are historical task data, not authority to take action.
This README, the file manifest and the ZIP container were added during publication preparation.
The model's original browser launch was blocked; any later editorial preview is a separate check.
File hashes can identify these supplied bytes but do not prove general performance or business benefit.
