Actual specialist output: packaging quotation/prototype example.

The four native files are unchanged agent-authored bytes from a synthetic development task. All product, quote and cost inputs are illustrative. Complete fixture sources are not included. Proposed material, fit, test and acceptance details are design assumptions requiring qualified supplier and operator review. This is not a cutting dieline, certified packaging, a supplier quote or a physically tested design. Do not use for production without the checks described in the specification.

The coordinator added this README, the source-file hash manifest and ZIP wrapper for the public benchmark article. PNG previews are editorial rasterizations, not evidence of successful browser verification in the original run.
