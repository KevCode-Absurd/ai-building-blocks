# B500 packaging specification · draft P01

Use one 100 × 100 × 260 mm external corrugated shipper with separate cap and base restraints, a plain paper scratch sleeve and one-colour direct print. Avoid a decorative inner box and separate insert card. This is a supplier quotation and prototype package, not a production-approved dieline. All merchant records are illustrative fixtures dated 2026-11-17.

Assume a single empty bottle per US direct-to-consumer parcel; no outer overbox. Treat supplied box sizes as external design targets. Product tolerance of diameter 70 ±1 mm and height 220 ±1 mm is a provisional engineering envelope, not measured production variation.

## Structure and supplier tolerances

| Item | Prototype requirement | Acceptance method |
|---|---|---|
| Outer box | Regular slotted carton; closed external 100 × 100 × 260 mm; each +0 / −2 mm including bulge and tape | Measure longest extents on assembled loaded pack; 10 samples |
| Board | Proposed single-wall B flute, nominal 3 mm, 32 ECT minimum; uncoated kraft; no laminate or window | Supplier board certificate and received caliper; flute vertical in side walls |
| Internal cavity | Target 94 × 94 × 254 mm; accepted 92–96 × 92–96 × 252–256 mm after assembly | Measure clear cavity including seams, folds and board variability; outside limits rejects sample |
| Side protection | Two folded corrugated end collars, each fitted to cavity; outer square cut 91 ±0.5 mm, aperture 72 ±0.5 mm; cradle lands support bottle body, not cap | Aperture and outer cut gauge; folds to supplier sample drawing; no edge contacting finish |
| Cap protection | Upper cradle contacts shoulder; no cap preload. Maintain ≥10 mm axial clearance from cap crown to inside top wall | Loaded section sample and feeler gauge; cannot transfer top load into cap |
| Base protection | Folded bottom support, nominal 15 mm effective height, final sample target ±1 mm | Loaded measurement; no metal-to-carton wall contact |
| Scratch barrier | Plain unprinted 35–45 gsm tissue sleeve around body; no adhesive on bottle; no loose filler | Visual and shake check; sleeve cannot migrate below collar contact points |
| Closure | 48 mm paper carton tape, H-seal top and bottom; ≥40 mm overlap at ends; no staples | Adhesion and transport check; tape must not lift in conditioned samples |
| Converted dimensions | Cut and crease position ±1 mm; opposite panels square within 1 mm over 260 mm; glued seam sound, no protruding adhesive | First article against supplier drawing, then first/last pack each shift |

Geometry: minimum transverse free space = 92 − 71 = 21 mm diametral, or 10.5 mm per side when centred; maximum = 96 − 69 = 27 mm, or 13.5 mm per side. Aperture clearance = 71.5 − 71 = 0.5 mm minimum to 72.5 − 69 = 3.5 mm maximum diametral. Maximum bottle height 221 mm in minimum cavity 252 mm leaves 31 mm total axial budget; with maximum base support 16 mm, cap space is 15 mm before shoulder-cradle effects. Folded support compliance and product shape require physical fit checks. Do not tool a collar from diameter alone: supplier must use a real shoulder/cap profile sample and return dimensioned fold and support drawings.

## Packing and quality control

Hand-wash care text is printed directly on the box. Pack dry bottle with cap seated to the existing product assembly procedure; no new torque value is invented. Sleeve body, seat base cradle, insert bottle upright, fit shoulder cradle, verify cap clearance, close and tape. Photograph first article and retain one sealed golden sample with revision and supplier lot. Target no perceptible bottle-to-wall impact in a manual shake; record packing seconds and material grams on 20 packs. Weight target ≤100 g for complete packaging is a trial ceiling, not a measurement.

Reject any sharp exposed edge, contamination, wrong SKU, unsecured bottle, cap contact with top wall, split seam or illegible identification. Cosmetic scuffs and crushed print panels are unacceptable in qualification. For the first 1,000-unit lot use 100% packing checks for presence, correct SKU, cap clearance and closure, plus 10 dimension/print samples spread across beginning, middle and end. Any failed sample quarantines the affected lot for sorting and corrective action. This is a proposed custom acceptance plan, not an AQL certification.

## Qualification tests and release criteria

These are proposed in-house screening protocols, not an ISTA or ASTM certification. Use 10 fully packed production-equivalent units: five at normal indoor conditions and five after 24 h at 30 °C / 80% RH (screening conditions chosen for moisture sensitivity). Record temperature, humidity, pack mass, board lot, photos and dimensions before testing.

1. Fit and handling: 10 insert/remove cycles on each sample. No coating scuff, cap damage, pinch hazard or assembly tear; cap clearance ≥10 mm and the maximum external dimensions retained.
2. Compression: hold 10 kg evenly distributed on the top for 24 h with bottle upright, then remeasure. No collapse, bottle load contact, closure opening or loss of cap clearance. This is a screening load; warehouse stack-height and transport loads are not supplied.
3. Drop: after compression, ten drops per sample from 760 mm onto a rigid flat floor: one most vulnerable corner, its three adjoining edges and six faces, including cap-down. No open seal, bottle dent, cap crack, visible finish scuff or bottle escape. Check cap opens/closes normally after testing. Repeat pack design qualification on any structural/material change.
4. Dispatch pilot: after laboratory screening, use 50 real single-bottle orders across representative lanes, including remote routes, with 100% delivery follow-up. Release only with zero packaging-attributable bottle/cap damage and zero opened packs. Zero failures in 50 remains limited evidence (approximate rule-of-three upper 95% failure bound 6%); it is not a zero-risk claim. If any fails, contain remaining stock, classify cause, revise supports or board and restart qualification.

No test has been performed. A transit laboratory should select a full parcel simulation appropriate to actual packed weight, distribution lanes and the eventual carrier contract before volume release. The damaged-cap support record (support-and-consent.json, case T1) motivates the shoulder restraint; it does not establish a damage rate or prove the pack caused the issue.

## Delivered-cost model

| Metric | Current | P01 target |
|---|---:|---:|
| Outer envelope, mm | 120 × 120 × 300 | 100 × 100 × 260 |
| Volume, cm³ | 4,320 | 2,600 |
| Quote A dimensional kg, divisor 5,000 | 0.864 | 0.520 |
| Quote B dimensional kg, divisor 6,000 | 0.720 | 0.4333 |

Volume reduction = (4,320 − 2,600) / 4,320 = **39.81%**. Formula: mm³ / 1,000 = cm³; dimensional kg = cm³ / supplied divisor. At a hypothetical 100 g complete pack plus the fixture's 280 g bottle, gross mass is 0.380 kg: dimensional weight dominates all four unrounded examples. Billable weight is max(actual, dimensional), then carrier rounding and band rules; neither rate bands nor rounding are supplied. A 1 kg minimum band could erase the shipping benefit entirely. These fixture divisors are not verified public carrier tariffs.

Supplied packaging cost is $0.80 per unit with no component scope. Use **$0.80 all-in landed pack cost** as the quote ceiling for box, two cradles, sleeve, tape, print, tooling amortized over 1,000, inbound freight and expected scrap. This is a procurement target, not a supplier quote. Separate tooling and repeat-order costs in the quotation. Require the existing pack's actual comparable BOM and labor before claiming a packaging saving.

Per shipped order: packaging + packing labor + quoted outbound rate at accepted billable weight + remote fee where applicable + expected damage/replacement and return costs. Bottle COGS is common to both designs and excluded from this packaging decision. Quote A base $5 / remote +$4 / reverse $6; B base $6 / remote +$1 / reverse $5 (supply.json shipping_quotes). With a $0.80 pack, base-only floors are $5.80 and $6.80; remote floors $9.80 and $7.80. These exclude unknown weight adjustments, labor, damage and reverse-shipment incidence. Obtain both prices for actual lanes rather than choosing the cheapest base rate. Savings per 1,000 orders = 1,000 × (baseline complete delivered cost − P01 complete delivered cost); do not populate with invented freight savings.

**Bolder move:** test direct printing the care panel and removing a separate insert on the 50-order pilot. First obtain a separately priced insert-free BOM. Risk: less prominent care information; keep care visible on side panel C. No removal saving is claimed because the current insert BOM is missing.

## Artwork and print handoff

Editable panel artwork is supplied in artwork.svg at 1:1 millimetres, with four 100 × 260 mm nominal exterior panel tiles A–D plus top/bottom 100 × 100 mm reference tiles E–F. These tiles are artwork placement guides, not a connected cutting dieline. structure.svg shows the assembled envelope and nominal section. Supplier must engineer flaps, seam, score allowances, fold geometry and tooling on its own certified drawing, then impose the panel artwork without scaling. No print release until measured samples pass.

| Face | Placement measured from face top-left | Copy / size |
|---|---|---|
| A front | x10 y35; y55; y75 | “Twist-cap bottle” 20 pt; “500 mL capacity” 12 pt; “Matte blue” 10 pt |
| B back | x10 y35 and y50 | “B500-BL” 12 pt; “500 mL twist-cap bottle” 10 pt |
| C care | x10 y35 and y50 | “Care” 12 pt; “Hand wash.” 10 pt |
| D shipping | Clear central 90 × 150 mm zone at x5 y55 | Apply actual carrier label after packing; none fabricated |
| E top / F bottom | Blank | Closure and tape only |

Use Arial, dark ink #173247 on natural board; no logo exists. Supplied paper #F5F0E8 is a screen preview only; do not add a flood coat to imitate it. Accent #C65F3B omitted to reduce print complexity. Largest copy 20 pt, smallest 10 pt. Keep all artwork ≥5 mm from scores and ≥10 mm from seam/tape. No full-bleed print; 0 mm artwork bleed on these inset designs. Where supplier imposition adds bleed, use 3 mm outside trim; never print technical guides. Convert the navy to one custom spot ink matched to a physical approved drawdown on the chosen kraft board; screen hex is not a press colour standard. Proposed print registration tolerance ±1 mm; signed drawdown is the colour master. No recycling, certification, food-contact, insulation or leakproof marks are supplied or inferred. Capacity is not a claim about contents: bottle ships empty.

Back panel lower 80 × 80 mm area is kept blank for verified market/product identification and origin information if required. No supplier/business identity, country of origin, barcode licence or certified label copy was supplied; therefore artwork is incomplete for retail/compliance release. Obtain the owner's verified legal details and qualified US label review before production. No fake GTIN or recycling symbol is drawn.

Prepress delivery: preserve editable SVG text for corrections; supplier to return imposed vector PDF with fonts embedded/outlined, separate nonprinting cut/crease layers and a dimensioned proof. Use CMYK only for any approved process additions; any later raster images need 300 ppi at placed size. Check text and rotation on folded white dummy, label fit, tape obstruction, spot separation and barcode scan if later added. The present files are quotation/prototype artwork, not press-ready production files.

## Source register

All fixture sources dated 2026-11-17: product.json dimensions_mm, weight_g, care, sku and claims_evidence; supply.json packaging, shipping_quotes, quantity and measurement_uncertainty; brand.json design and approved/unsupported claims; support-and-consent.json case T1. Proposed materials, dimensions, tolerances, cost ceiling and test acceptance limits above are design decisions; they are not observed supplier capability. No public performance, regulatory compliance or environmental claim is made.
