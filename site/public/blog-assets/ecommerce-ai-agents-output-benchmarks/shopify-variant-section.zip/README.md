# Install and release

This is a local draft for the illustrative B500 fixture, not a complete theme or a published preview. No additional production packages were added. Runtime: Shopify Liquid plus plain browser JavaScript/CSS. Tests used Node 24.19.0 and the supplied Playwright installation; its version is not pinned by this deliverable.

Files:
- `product-section.liquid` → unpublished theme `sections/product-section.liquid`.
- `product-availability.js`, `product-availability.css` → unpublished theme `assets/`.
- `product-page.html` and unchanged `product.svg` → local demonstration only; never submit its synthetic IDs to a real store.

Use the section in the B500 product template on a duplicate theme, replacing the old section rather than adding another product heading/form. The supplied single-section baseline had no cart drawer, quantity picker, image gallery or purchase-plan controls. None have been invented. The production section retains native POST navigation to the cart; it does not implement AJAX drawer behavior.

The section's editable dimensions default is the supplied B500 specification: 70 mm diameter × 220 mm height. Restrict this section/template to B500, or change its dimension setting for other products. Availability and formatted prices come from Shopify product variants; fixture IDs, stock counts and USD price are not hardcoded into Liquid. Variant option labels expose stock state even without JavaScript. Sold-out options are disabled; if an unavailable variant is initially selected by Shopify, the button is disabled until an available variant is selected. All-sold-out products keep the submit button disabled. No client-side guard is a substitute for Shopify's stock enforcement.

To run local behavior checks from the case root: `node context/test.cjs`. It starts and closes a loopback fixture server, intercepts POSTs locally and launches Chrome with its sandbox enabled. Browser infrastructure must be available; no packages need installing. Static syntax: `node --check output/product-availability.js`. Native schema/source checks: `python context/finalize.py`.

Release checklist (not yet executed):
1. Record the current live theme ID, duplicate it, upload the three production files, and assign the B500 template in preview only. Run Shopify Theme Check in the team's supported environment; no Shopify CLI or Liquid engine was supplied here.
2. Preview Blue and Clay, including direct `?variant=` links and an all-unavailable test product. Check selected option, formatted price/currency, dimensions, status and button; repeat with JavaScript disabled. The section does not update variant URLs or other theme components.
3. Add Blue once; verify the cart contains its real Shopify variant ID with quantity 1. Try Clay; verify no line is added. Simulate stock selling out after the page loads and confirm Shopify rejects the unavailable item with its native error response. Test a product with different variant prices.
4. Verify cart navigation, removal, quantity changes, discounts and checkout entry. Confirm header/footer, other product templates, theme-editor section reloads and app blocks retain prior behavior. Test keyboard navigation and a screen reader announcement of stock state; check at 200% zoom, 360px, desktop, Safari/iOS and Android.
5. Owner reviews the unpublished preview and integration results before deciding on release. Keep the previous theme available; rollback by republishing that recorded theme if cart or variant behavior fails after release.

No before/after speed or commercial improvement is claimed. No production integration, checkout, screen reader, Safari, Android or independent review was performed.
