// Synchronize native variant selection; native POST remains the cart transport.
(function () {
  function init(root) {
    if (root.dataset.ready) return;
    root.dataset.ready = 'true';
    const form = root.querySelector('form');
    const select = form.querySelector('select[name="id"]');
    const button = form.querySelector('button[type="submit"]');
    const status = root.querySelector('[data-availability]');
    const price = root.querySelector('[data-price]');
    function update() {
      const option = select.selectedOptions[0];
      const available = Boolean(option && option.dataset.available === 'true');
      button.disabled = !available;
      button.textContent = available ? 'Add to cart' : 'Sold out';
      status.textContent = available ? 'In stock' : 'Sold out';
      if (option) price.textContent = option.dataset.price;
      return available;
    }
    select.addEventListener('change', update);
    form.addEventListener('submit', function (event) {
      if (!update()) { event.preventDefault(); select.focus(); }
    });
    update();
  }
  document.querySelectorAll('[data-bottle-product]').forEach(init);
  document.addEventListener('shopify:section:load', function(event) {
    event.target.querySelectorAll('[data-bottle-product]').forEach(init);
  });
})();