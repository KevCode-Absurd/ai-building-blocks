# Installation and rollback

All commands run from this assigned run folder. The ZIP is immutable. Requires the already installed Node 24.19.0, Playground CLI dependency referenced by the supplied launcher, and installed Edge/Playwright path in the scripts. No native PHP/MySQL is required.

1. Create `context/` and `output/`. Copy `evidence/launch-wordpress.mjs` to `context/launch-wordpress.mjs`.
2. Extract `evidence/wordpress-woocommerce-baseline.zip` separately to `context/baseline-site` and `context/candidate-site`. Do not merge with a running site's files.
3. Copy `output/native-emoji-candidate.php` to `context/candidate-site/wp-content/mu-plugins/native-emoji-candidate.php`. An MU-plugin loads automatically; no activation or DB update is needed.
4. Run `node context/launch-wordpress.mjs context/baseline-site 9492` in one terminal; run the same command with `context/candidate-site 9493` in another. Both bind only 127.0.0.1 with six workers. These are isolated copies, never the reference or shared merchant server.
5. Run `node context/functional.mjs`. It uses two fresh browser contexts per copy, nonce-authenticated cookie cart requests and rendered page checks. No order/payment/mail request is made. `output/functional-attempt1.mjs` and `output/functional-attempt2.mjs` reproduce the retained unsuccessful test approaches; use the corrected context script for verification.
6. In an explicitly exclusive measurement window, run `node context/measure.mjs`. Do not run functional tests, builds or other browser jobs concurrently. See `measurement-protocol.json`. This takes fresh anonymous contexts, not the prior functional sessions.
7. Verify catalogue responses include `X-Native-Emoji-Candidate: 1` and omit `wp-emoji-settings`; compare public catalogue HTML. Cart/checkout/account must retain their normal Woo assets and privacy behavior.

Rollback: stop the candidate launcher with Ctrl+C, remove only `context/candidate-site/wp-content/mu-plugins/native-emoji-candidate.php`, then restart the same launcher. No DB rollback is needed for this plugin. Recheck that the header disappears and emoji loader returns; the separately extracted baseline is the recovery reference. Never restore this synthetic DB over a merchant DB. Synthetic carts created during tests are isolated here; product identities/prices/stock must not be changed. Guards and core stay byte-identical.

This patch only removes WordPress's compatibility emoji loader/styles from shop and single-product pages; modern native emoji remains browser-dependent. Old-browser emoji fallback is the tradeoff. It does not remove WooCommerce cart fragments, checkout scripts, assets, plugins, scheduling or security rules, and does not install a page/object cache. Before production deployment validate the supported browser matrix and real merchant emoji content. Recommendation is retain baseline unless the report's evidence supports a release.
