<?php
/** Plugin Name: Synthetic storefront native emoji candidate
 * Removes WordPress emoji compatibility loader only on public catalogue pages.
 * Modern browser native emoji remains; carts/checkout/account are untouched.
 */
add_action('wp', function () {
    if ( ! is_admin() && ( is_shop() || is_product() ) ) {
        remove_action('wp_head', 'print_emoji_detection_script', 7);
        remove_action('wp_enqueue_scripts', 'wp_enqueue_emoji_styles');
        remove_action('wp_print_styles', 'print_emoji_styles');
        add_action('send_headers', function () { header('X-Native-Emoji-Candidate: 1'); });
        // wp runs after send_headers; emit an execution receipt directly.
        if (!headers_sent()) header('X-Native-Emoji-Candidate: 1');
    }
});
