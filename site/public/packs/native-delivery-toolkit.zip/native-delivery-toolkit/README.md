# AI Blocks native delivery toolkit

Download: https://useaiblocks.com/packs/native-delivery-toolkit.zip

This toolkit makes no model/API calls, uses no API keys and does not run project build scripts or generation. It checks actual local file bytes, raster decoding/dimensions and bounded offline static-page behaviour. It does not certify brand fidelity, launch readiness or business outcomes.

Requirements: Node.js 22+, npm, and installed Chrome (or Edge). Install the two pinned local dependencies from this extracted directory:

    npm --prefix site install

The install downloads ordinary npm packages; it does not buy or use model credits. Browser binaries are not bundled or installed by this toolkit. To use Edge add --browser msedge to inspection commands.

Run the included local fixture from this extracted directory:

    node tools/inspect-native-delivery.mjs inspect --root C:/absolute/path/to/native-delivery-toolkit --manifest examples/inspection.json

On macOS/Linux use your absolute extracted path for --root. The fixture is a small mechanical test only, not a landing-page design recommendation or evidence of model/output quality.

For your actual work, choose an explicitly authorized project root, create a manifest with actual hashes and list every local preview asset. Read docs/NATIVE-DELIVERY-ADAPTER.md. Do not copy private brand/project files into this toolkit's public download.

Before producing native files in a connected AI, check the actual host tools:

    node tools/inspect-native-delivery.mjs preflight --root C:/absolute/path/to/native-delivery-toolkit --manifest examples/preflight.json

The sample preflight intentionally returns BLOCKED because it has no host tools. Supply fresh actual tool availability receipts; do not invent availability. Paid tools are rejected by the CLI, even if a file tries to enable them.

SOURCE-MANIFEST.json hashes every other file in this archive. Reports go to stdout; nothing is saved automatically. Keep reports and project evidence private. PASS means only the enumerated mechanical checks passed; PARTIAL/FAIL return a nonzero exit code.
