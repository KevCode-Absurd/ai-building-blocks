AI agent starter pack, from AI Blocks (useaiblocks.com/train-your-own-ai-agent)

Your agent is this folder. Your AI reads it before every job.

AGENT.md        The job: what it is, who it's for, how you like it done.
RULES.md        What your agent learns from your edits, one rule at a time.
EXAMPLES.md     Good and bad examples of the job.
PERMISSIONS.md  What it may do on its own, and what needs your OK.
CHECKS.md       Yes or no checks, serious mistakes and three test jobs.
SCORECARD.md    One line per job you check, and the four levels.
PROMPTS.md      Five prompts: build, do a job, learn from an edit, grade, tidy up.
SETUP.md        Where to put the files in ChatGPT, Claude, Gemini and coding agents.

Start with prompt 1 in PROMPTS.md. The full guide is on the page above.
Never put passwords, keys, ID or bank numbers, health details or private
facts about other people in these files.
