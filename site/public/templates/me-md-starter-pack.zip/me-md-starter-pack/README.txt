me.md starter pack, from AI Blocks (useaiblocks.com/me-md)

me.md                 The template. Fill in what helps and delete the rest.
me-core.txt           The short core for your AI's settings box.
me-md-prompts.md      Prompts to make your me.md with your AI, and to refresh it.
me-md-setup-guide.md  Where to put it in ChatGPT, Claude, Claude Code, Gemini and Cursor.

Keep your me.md private. Never add passwords, ID or bank numbers, health details
or private facts about other people.
